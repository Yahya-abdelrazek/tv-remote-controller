import serial
from pynput.keyboard import Controller, Key
import time

SERIAL_PORT = 'COM3'  # Change to your Arduino port
BAUD_RATE = 9600

keyboard = Controller()

key_map = {
    "Ok": Key.esc,            # example mapping "Ok" to esc
    "Left": 'z',
    "Right": 'c',
    "Down": 'x',
    "Up": 's',
    "volume_up": Key.space,
    "volume_down": Key.down,
    # Add more mappings as needed
}

def main():
    try:
        ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
        time.sleep(2)  # wait for Arduino to initialize
        print(f"Connected to Arduino on {SERIAL_PORT}")

        while True:
            if ser.in_waiting > 0:
                line = ser.readline().decode('utf-8').strip()
                if line:
                    print(f"Received: {line}")

                    # Parse the command from the line
                    if line.startswith("Button pressed: "):
                        cmd = line[len("Button pressed: "):].strip()
                    elif line.startswith("IR code: "):
                        cmd = None  # ignoring raw IR codes here, or handle as you want
                    else:
                        cmd = line  # fallback, just use the whole line

                    if cmd and cmd in key_map:
                        keyboard.press(key_map[cmd])
                        keyboard.release(key_map[cmd])
                    else:
                        print(f"Unmapped command: {line}")

    except serial.SerialException as e:
        print(f"Error opening serial port: {e}")

if __name__ == "__main__":
    main()
